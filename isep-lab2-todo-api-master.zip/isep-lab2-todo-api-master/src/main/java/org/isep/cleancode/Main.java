package org.isep.cleancode;

import org.isep.cleancode.application.ITodoRepository;
import org.isep.cleancode.application.TodoManager;
import org.isep.cleancode.persistence.csvfiles.TodoCsvFilesRepository;
import org.isep.cleancode.persistence.inmemory.TodoInMemoryRepository;
import org.isep.cleancode.presentation.TodoController;

import static spark.Spark.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        port(4567);

        String repoType = "CSV"; 
        if (args.length > 0) {
            try {
                List<String> lines = Files.readAllLines(Paths.get(args[0]));
                for (String line : lines) {
                    if (line.startsWith("repository=")) {
                        repoType = line.split("=")[1].trim();
                        break;
                    }
                }
            } catch (IOException e) {
                System.out.println("Config file not found. Using default: CSV");
            }
        }

        ITodoRepository repository = switch (repoType.toUpperCase()) {
            case "INMEMORY" -> new TodoInMemoryRepository();
            case "CSV" -> new TodoCsvFilesRepository();
            default -> throw new RuntimeException("Unknown repository: " + repoType);
        };

        TodoManager manager = new TodoManager(repository);
        TodoController controller = new TodoController(manager);

        post("/todos", controller::createTodo);
        get("/todos", controller::getAllTodos);
    }
}
