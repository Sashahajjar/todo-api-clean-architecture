package org.isep.cleancode;

import java.time.LocalDate;

public class Todo {

    private String name;
    private LocalDate dueDate;

    public Todo(String name, LocalDate dueDate) {
        if (name == null || name.isBlank() || name.length() >= 64) {
            throw new IllegalArgumentException("Name is required and must be less than 64 characters");
        }
        this.name = name;
        this.dueDate = dueDate;
    }

    public String getName() {
        return name;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }
}
