package org.isep.cleancode.application;

import org.isep.cleancode.Todo;
import java.time.LocalDate;
import java.util.List;

public class TodoManager {
    private final ITodoRepository repository;

    public TodoManager(ITodoRepository repository) {
        this.repository = repository;
    }

    public Todo createTodo(String name, String dueDateStr) {
        if (name == null || name.isBlank() || name.length() >= 64) {
            throw new RuntimeException("Invalid name");
        }
    
        if (repository.existsByName(name)) {
            throw new RuntimeException("Duplicate name");
        }
    
        LocalDate dueDate = null;
        if (dueDateStr != null && !dueDateStr.isBlank()) {
            try {
                dueDate = LocalDate.parse(dueDateStr);
            } catch (Exception e) {
                throw new RuntimeException("Invalid date format");
            }
        }
    
        Todo todo = new Todo(name, dueDate);
        repository.addTodo(todo);
        return todo;
    }
    
    public List<Todo> getAllTodos() {
        return repository.getAllTodos();
    }
}
