package org.isep.cleancode.persistence.csvfiles;

import org.isep.cleancode.Todo;
import org.isep.cleancode.application.ITodoRepository;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TodoCsvFilesRepository implements ITodoRepository {

    private final Path filePath;

    public TodoCsvFilesRepository() {
        String appData = System.getenv("APPDATA");  
        if (appData == null) {
            appData = System.getProperty("user.home");
        }
        this.filePath = Paths.get(appData, "todos.csv");
        ensureFileExists();
    }

    private void ensureFileExists() {
        try {
            if (!Files.exists(filePath)) {
                Files.createFile(filePath);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not create CSV file", e);
        }
    }

    @Override
    public void addTodo(Todo todo) {
        try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.APPEND)) {
            writer.write(todo.getName() + "," + (todo.getDueDate() != null ? todo.getDueDate() : "") + "\n");
        } catch (IOException e) {
            throw new RuntimeException("Error writing to CSV", e);
        }
    }

    @Override
    public List<Todo> getAllTodos() {
        List<Todo> todos = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                String name = parts[0];
                LocalDate dueDate = parts[1].isEmpty() ? null : LocalDate.parse(parts[1]);
                todos.add(new Todo(name, dueDate));
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading CSV", e);
        }
        return todos;
    }

    @Override
    public boolean existsByName(String name) {
        return getAllTodos().stream().anyMatch(t -> t.getName().equals(name));
    }
}
