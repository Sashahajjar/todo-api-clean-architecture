package org.isep.cleancode.presentation;

import com.google.gson.*;
import org.isep.cleancode.Todo;
import org.isep.cleancode.application.TodoManager;

import spark.Request;
import spark.Response;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.Map;

public class TodoController {

    private static final Gson gson = new GsonBuilder()
        .registerTypeAdapter(LocalDate.class, new JsonDeserializer<LocalDate>() {
            public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                    throws JsonParseException {
                return LocalDate.parse(json.getAsString());
            }
        })
        .registerTypeAdapter(LocalDate.class, new JsonSerializer<LocalDate>() {
            public JsonElement serialize(LocalDate src, Type typeOfSrc, JsonSerializationContext context) {
                return new JsonPrimitive(src.toString());
            }
        })
        .create();

        private final TodoManager todoManager;

        public TodoController(TodoManager todoManager) {
            this.todoManager = todoManager;
        }
                
    public Object getAllTodos(Request req, Response res) {
        res.type("application/json");
        return gson.toJson(todoManager.getAllTodos());
    }

    public Object createTodo(Request req, Response res) {
        res.type("application/json");

        @SuppressWarnings("unchecked")
        Map<String, Object> body = gson.fromJson(req.body(), Map.class);
        String name = (String) body.get("name");
        String dueDateStr = (String) body.get("dueDate");

        try {
            Todo todo = todoManager.createTodo(name, dueDateStr);
            res.status(201);
            return gson.toJson(todo);
        } catch (Exception e) {
            res.status(400);
            return gson.toJson(e.getMessage());
        }
    }
}
